import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# ------------------------------------------------------------------------------
# Constants and Parameters
# ------------------------------------------------------------------------------
MU_MARS = 4.282837e13        # Gravitational parameter of Mars, [m^3 / s^2]
R_MARS = 3_389_500.0         # Mean radius of Mars, [m]
MARS_SURFACE_PENETRATION = 0.61  # 2 ft in meters

# Choose an initial circular orbit altitude (300 km above surface)
ORBIT_ALTITUDE = 300_000.0
ORBIT_RADIUS = R_MARS + ORBIT_ALTITUDE

# Circular orbit velocity
V_ORBIT = np.sqrt(MU_MARS / ORBIT_RADIUS)

# Simulation time settings
TIME_STEP = 0.1     # Smaller step for better collision resolution
TOTAL_TIME = 12_000.0
t_vals = np.arange(0, TOTAL_TIME, TIME_STEP)

# Drop time for penetrator
t_drop = 30       # 30 seconds into the orbit

# ------------------------------------------------------------------------------
# RK4 Integrator
# ------------------------------------------------------------------------------
def derivatives(t, state):
    """
    state = [x, y, vx, vy]
    returns derivatives = [vx, vy, ax, ay]
    """
    x, y, vx, vy = state
    r = np.sqrt(x**2 + y**2)
    ax = -MU_MARS * x / r**3
    ay = -MU_MARS * y / r**3
    return np.array([vx, vy, ax, ay])

def rk4_step(func, t, state, dt):
    k1 = func(t, state)
    k2 = func(t + dt/2, state + dt*k1/2)
    k3 = func(t + dt/2, state + dt*k2/2)
    k4 = func(t + dt,   state + dt*k3)
    return state + (dt/6)*(k1 + 2*k2 + 2*k3 + k4)

# ------------------------------------------------------------------------------
# Initial Conditions
# ------------------------------------------------------------------------------
satellite_state = np.array([ORBIT_RADIUS, 0.0, 0.0, V_ORBIT])
penetrator_state = np.array([ORBIT_RADIUS, 0.0, 0.0, V_ORBIT])

# Arrays to store trajectory
satellite_positions = []
penetrator_positions = []

# Flags
penetrator_released = False
penetrator_impact = False

# ------------------------------------------------------------------------------
# Main Simulation Loop
# ------------------------------------------------------------------------------
current_sat_state = satellite_state.copy()
current_pen_state = penetrator_state.copy()

for i, t in enumerate(t_vals):
    # Update the satellite
    current_sat_state = rk4_step(derivatives, t, current_sat_state, TIME_STEP)

    # Release penetrator with a velocity change at t_drop
    if (not penetrator_released) and (t >= t_drop):
        penetrator_released = True
        current_pen_state = current_sat_state.copy()
        
        # De-orbit burn: reduce velocity more significantly (15%):
        current_pen_state[2] *= 0.85
        current_pen_state[3] *= 0.85

    # If penetrator is released and not impacted, update it
    if penetrator_released and (not penetrator_impact):
        new_pen_state = rk4_step(derivatives, t, current_pen_state, TIME_STEP)
        x_p, y_p, vx_p, vy_p = new_pen_state
        r_p = np.sqrt(x_p**2 + y_p**2)
        
        # Slight margin so it doesn't visually 'hover' above surface
        if r_p <= R_MARS - 1.0:
            # Impact: place penetrator below surface
            penetrator_impact = True
            direction = np.array([x_p, y_p]) / r_p
            new_pen_position = direction * (R_MARS - MARS_SURFACE_PENETRATION)
            new_pen_state[0] = new_pen_position[0]
            new_pen_state[1] = new_pen_position[1]
            new_pen_state[2] = 0.0
            new_pen_state[3] = 0.0
        current_pen_state = new_pen_state

    satellite_positions.append(current_sat_state[:2].copy())
    penetrator_positions.append(current_pen_state[:2].copy())

satellite_positions = np.array(satellite_positions)
penetrator_positions = np.array(penetrator_positions)

# ------------------------------------------------------------------------------
# Animation Setup
# ------------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(6, 6))
ax.set_aspect('equal', 'box')

# Load Mars image (adjust path if needed)
mars_img = plt.imread("mars_image.png")
ax.imshow(
    mars_img,
    extent=[-R_MARS, R_MARS, -R_MARS, R_MARS],
    origin='lower',
    zorder=0
)

# Plot limits: 1.2 * ORBIT_RADIUS
ax.set_xlim(-1.2 * ORBIT_RADIUS, 1.2 * ORBIT_RADIUS)
ax.set_ylim(-1.2 * ORBIT_RADIUS, 1.2 * ORBIT_RADIUS)
ax.set_title("Satellite Orbit and Kinetic Penetrator on Mars")

# Markers and lines
sat_point, = ax.plot([], [], 'bo', markersize=8, label='Satellite')
pen_point, = ax.plot([], [], 'go', markersize=8, label='Penetrator')
sat_traj, = ax.plot([], [], 'b--', linewidth=1, alpha=0.7)
pen_traj, = ax.plot([], [], 'g--', linewidth=1, alpha=0.7)
ax.legend()

def init():
    sat_point.set_data([], [])
    pen_point.set_data([], [])
    sat_traj.set_data([], [])
    pen_traj.set_data([], [])
    return sat_point, pen_point, sat_traj, pen_traj

# ------------------------------------------------------------------------------
# Skipping Frames for Smoother Animation
# ------------------------------------------------------------------------------
num_frames_to_show = 600
frames_to_animate = np.linspace(
    0, len(satellite_positions) - 1, 
    num_frames_to_show, 
    dtype=int
)
# 600 frames * 200 ms per frame = 120 s (2 min)
interval_ms = 200

def update(frame_index):
    sx, sy = satellite_positions[frame_index]
    px, py = penetrator_positions[frame_index]

    # Single-point sequences for marker updates
    sat_point.set_data([sx], [sy])
    pen_point.set_data([px], [py])

    # For trajectory lines, we pass slices
    sat_traj.set_data(
        satellite_positions[:frame_index+1, 0],
        satellite_positions[:frame_index+1, 1]
    )
    pen_traj.set_data(
        penetrator_positions[:frame_index+1, 0],
        penetrator_positions[:frame_index+1, 1]
    )

    return sat_point, pen_point, sat_traj, pen_traj

ani = FuncAnimation(
    fig,
    update,
    frames=frames_to_animate,
    init_func=init,
    blit=False,
    interval=interval_ms
)

plt.show()
